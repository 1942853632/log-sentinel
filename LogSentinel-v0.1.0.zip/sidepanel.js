import { analyzeLogs, toMarkdown } from './analyzer.js';
const input = document.querySelector('#input');
const result = document.querySelector('#result');
let markdown = '';
function run() { const report = analyzeLogs(input.value); markdown = toMarkdown(report); result.textContent = markdown; }
document.querySelector('#analyze')?.addEventListener('click', run);
document.querySelector('#copy')?.addEventListener('click', () => { if (markdown)
    void navigator.clipboard.writeText(markdown); });
run();
