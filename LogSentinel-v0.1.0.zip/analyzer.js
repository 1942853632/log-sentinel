const rules = [
    { kind: 'incident', rule: 'error-burst', pattern: /\b(error|fatal|panic|exception|traceback)\b/i, message: 'Error signal detected; group repeated events before triage.' },
    { kind: 'incident', rule: 'timeout', pattern: /\b(timeout|timed out|deadline exceeded)\b/i, message: 'Timeout signal detected; inspect dependency latency and retries.' },
    { kind: 'privacy', rule: 'secret-like', pattern: /(api[_-]?key|authorization:\s*bearer|password\s*=|secret\s*=)/i, message: 'Possible credential in logs; rotate it and add redaction.' },
    { kind: 'privacy', rule: 'email', pattern: /\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/i, message: 'Email address detected; verify that PII is not being logged.' },
    { kind: 'observability', rule: 'missing-request-id', pattern: /(request|trace|correlation)[-_ ]?id/i, message: 'Request identifier is present in one line; confirm it is propagated consistently.' }
];
export function analyzeLogs(text) { const lines = text.split(/\r?\n/).filter(line => line.trim()); const findings = []; let errors = 0; for (const [index, line] of lines.entries()) {
    if (/\b(error|fatal|panic|exception|traceback)\b/i.test(line))
        errors++;
    for (const rule of rules)
        if (rule.pattern.test(line))
            findings.push({ kind: rule.kind, rule: rule.rule, line: index + 1, message: rule.message, evidence: line.trim().slice(0, 220) });
} const privacy = findings.filter(f => f.kind === 'privacy').length; const incident = findings.filter(f => f.kind === 'incident').length; return { lines: lines.length, errors, findings, score: Math.max(0, 100 - incident * 15 - privacy * 30), verdict: privacy || incident > 3 ? 'incident' : findings.length ? 'review' : 'healthy' }; }
export function toMarkdown(report) { return [`# Log Sentinel Report`, ``, `- Verdict: **${report.verdict}**`, `- Score: **${report.score}/100**`, `- Non-empty lines: **${report.lines}**`, `- Error lines: **${report.errors}**`, ``, ...report.findings.map(f => `- **${f.kind}** \`${f.rule}\` line ${f.line}: ${f.message} — \`${f.evidence}\``)].join('\n'); }
